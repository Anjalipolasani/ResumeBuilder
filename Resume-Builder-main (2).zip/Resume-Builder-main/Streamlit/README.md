---
title: ResumeBuilder
emoji: 🌖
colorFrom: blue
colorTo: indigo
sdk: streamlit
sdk_version: 1.40.0
app_file: app.py
pinned: false
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference

Run the app on hugging face at https://huggingface.co/spaces/pktpaulie/resumeMagic


Enter both the resume and job description and see how well candidate matches the requirements

Improve the resume using one of the models

View the results and original resume

Download the improved resume