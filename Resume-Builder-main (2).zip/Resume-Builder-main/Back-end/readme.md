# Backend Flask Application

Steps to run the application.

1. Navigate to source directory
2. Run python3 -m pip install -r requirements.txt
3. Run python3 app.py

The application will execute in port 5000.
The file uploaded in the UI will be downloaded to /uploads folder and can be downloaded from /uploads/{filename}